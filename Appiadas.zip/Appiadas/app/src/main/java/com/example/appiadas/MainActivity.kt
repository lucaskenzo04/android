package com.example.appiadas

import android.media.MediaPlayer
import android.os.Bundle
import android.renderscript.ScriptGroup.Binding
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.appiadas.databinding.ActivityMainBinding
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btTellJoker.setOnClickListener {
            showJoker()
        }
    }

    private var lastJokerIndex = -1
    private fun showJoker() {
        val jokers =
            resources.getStringArray( R.array.jokers)
        var numberJoker =
            Random.nextInt( jokers.size)
        while (numberJoker ==
            lastJokerIndex ) {
            numberJoker =
                Random.nextInt( jokers.size)
        }
        val joker = jokers[numberJoker ]
        binding.tvJoker.text = joker
        lastJokerIndex = numberJoker
        playSong()
    }

    private fun playSong() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.badumtss)
        mediaPlayer.start()

    }

}






