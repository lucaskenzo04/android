package br.com.lucaskenzo04.formcheckpoint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import br.com.lucaskenzo04.formcheckpoint.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main);

        val btnEnviar: Button = findViewById(R.id.btnEnviar)
        btnEnviar.setOnClickListener {
            val etNome: EditText = findViewById(R.id.etNome)
            val etIdade: EditText = findViewById(R.id.etIdade)
            val etEmail: EditText = findViewById(R.id.etEmail)
            val etCpf: EditText = findViewById(R.id.etCpf)
            val rgSexo: RadioGroup = findViewById(R.id.rgSexo)

            val nome = etNome.text.toString()
            val idade = etIdade.text.toString()
            val email = etEmail.text.toString()
            val cpf = etCpf.text.toString()

            // Verifica qual RadioButton está selecionado
            val selectedId = rgSexo.checkedRadioButtonId
            val radioButton: RadioButton = findViewById(selectedId)
            val sexo = radioButton.text.toString()

            // Cria a intent para enviar os dados para a DisplayInfoActivity
            val intent = Intent(this, DisplayInfoActivity::class.java).apply {
                putExtra("NOME", nome)
                putExtra("IDADE", idade)
                putExtra("EMAIL", email)
                putExtra("CPF", cpf)
                putExtra("SEXO", sexo)
            }

            // Inicia a nova Activity
            startActivity(intent)
        }
    }
}
