package br.com.lucaskenzo04.formcheckpoint
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import br.com.lucaskenzo04.formcheckpoint.R

class DisplayInfoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_info);

        // Recebe os dados da Intent
        val nome = intent.getStringExtra("NOME")
        val idade = intent.getStringExtra("IDADE")
        val email = intent.getStringExtra("EMAIL")
        val cpf = intent.getStringExtra("CPF")
        val sexo = intent.getStringExtra("SEXO")

        // Exibe os dados nos TextView's
        val tvNome: TextView = findViewById(R.id.tvNome)
        val tvIdade: TextView = findViewById(R.id.tvIdade)
        val tvEmail: TextView = findViewById(R.id.tvEmail)
        val tvCpf: TextView = findViewById(R.id.tvCpf)
        val tvSexo: TextView = findViewById(R.id.tvSexo)

        tvNome.text = "Nome: $nome"
        tvIdade.text = "Idade: $idade"
        tvEmail.text = "E-mail: $email"
        tvCpf.text = "CPF: $cpf"
        tvSexo.text = "Sexo: $sexo"
    }
}
