package br.com.lucaskenzo.placar

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Variáveis para armazenar o placar
    private var homeScore = 0
    private var awayScore = 0

    // TextViews para exibir o placar
    private lateinit var tvHomeScore: TextView
    private lateinit var tvAwayScore: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializa os TextViews dos placares
        tvHomeScore = findViewById(R.id.tv_home_score)
        tvAwayScore = findViewById(R.id.tv_away_score)

        // Inicializa os botões de pontuação
        val btnHomePoint: Button = findViewById(R.id.btn_home_point)
        val btnAwayPoint: Button = findViewById(R.id.btn_away_point)

        // Inicializa o botão "Terminar Partida"
        val btnEndGame: Button = findViewById(R.id.btn_end_game)

        // Aumenta o placar da equipe HOME ao clicar no botão "PONTO"
        btnHomePoint.setOnClickListener {
            homeScore++
            tvHomeScore.text = homeScore.toString()
        }

        // Aumenta o placar da equipe AWAY ao clicar no botão "PONTO"
        btnAwayPoint.setOnClickListener {
            awayScore++
            tvAwayScore.text = awayScore.toString()
        }

        // Reseta os placares ao clicar no botão "TERMINAR PARTIDA"
        btnEndGame.setOnClickListener {
            homeScore = 0
            awayScore = 0
            tvHomeScore.text = homeScore.toString()
            tvAwayScore.text = awayScore.toString()
        }
    }
}
